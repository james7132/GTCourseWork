I used an unmodified RL-sim library found at https://www.cs.cmu.edu/~awm/rlsim/

The zip file includes information on how to run and use the jar.

The two MDPs used are stored as .maze files in the submitted tar.\
- "7_medium_complex_multigoal.maze" is the small maze, Maze 1, referenced in the analysis
- "big2.maze" is the large maze, Maze 2, referenced in the analysis